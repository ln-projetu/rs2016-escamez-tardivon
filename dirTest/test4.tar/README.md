# Projet de RS 2016: ptar
ptar est un gestionnaire d'archive avec intégration de la fonction de durabilité.
Il utilise les threads POSIX pour assurer la performance de ce processus relativement long.
